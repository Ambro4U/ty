<?php
$conn=mysql_connect("localhost","root","");//create connection
mysql_select_db("dbudms",$conn);//to select from the db
?>