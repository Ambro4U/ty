<div style="text-align:center; font-weight:bold;">Terms and Condition</div><br />
<p>1. The account is created only by the system administrator.</p>
<p>2. The user have the right to change password only.</p>
<p>3. In case the account is Deactivate the user should contact the system administrator .</p>
